


public class Main {
    public static void main(String[] args) {
        Evidence konzole = new Evidence();
        konzole.pracuj();
    }
}
